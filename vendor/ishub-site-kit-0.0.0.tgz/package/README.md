# @ishub/site-kit

Shared front-end kit for the Israeli service sites. One place to change a shared component, the SEO
scaffold, the design tokens, or the analytics loader, so every site picks it up on rebuild.

> **Status: Phase 1 DONE across the Next fleet (2026-07-09).** `./types` and `./contact` are
> implemented and **adopted in all 5 Next sites** — netomazganim, betonplus, gagoline, visionsecurity
> read NAP from a per-site `site.config.json` manifest and generate contact links from
> `@ishub/site-kit` (each verified byte-stable); 3locksmiths (a scraped snapshot with static contact
> HTML) has the manifest + package installed for future use. A shared-edit propagation test passed
> (one edit here reached all 50 of the pilot's pages on rebuild).
>
> **Phase 2 in progress (2026-07-12):** `./seo` (manifest-driven JSON-LD builders) is implemented and
> adopted across **all 4 builder-capable Next sites** — netomazganim (previously had NO structured
> data), gagoline, betonplus, visionsecurity — each verified to keep (or enrich) its fields; richer
> sites moved their hardcoded hours/logo/address into their manifests. visionsecurity keeps its
> English-primary business name via the `name`/`alternateName` opts. 3locksmiths stays on its baked
> snapshot JSON-LD (not a builder candidate). `./theme`, `./components`, `./analytics`,
> `./schema-routes` still planned.

## Exports

| Export | Status | Extracted from | Purpose |
|---|---|---|---|
| `./types` | done | (new; mirrors `roster/manifest.schema.json`) | `SiteManifest` — the normalized config shape all sites read |
| `./contact` | done | the 4 drifted `telHref`/`whatsappHref` variants | `telHref`, `whatsappHref`, `phoneDisplay`, `usesOwnNumber` |
| `./seo` | **done** (all 4 builder sites) | `betonplus.co.il/lib/seo.ts` | `localBusinessJsonLd(m, opts?)`, `serviceJsonLd`, `faqJsonLd`, `breadcrumbJsonLd`, `jsonLdScript` — all manifest-driven (`@type`/NAP/area/hours; opts for image/logo/name override). `pageMetadata` deferred (couples to `next` types) |
| `./schema-routes` | planned | `betonplus.co.il/app/robots.ts`, `app/sitemap.ts` | `buildRobots`, `buildSitemap` |
| `./analytics` | planned | new (only dangates has GTM today) | `<GtmLoader id=...>`, site-verification wiring |
| `./theme` | planned | betonplus `@theme` / v3 `tailwind.config.ts` | **Tailwind v4** preset (fleet standardized on v4) |
| `./components` | planned | `FloatingCTA`, `Header`, `Footer`, `ContactForm`/`LeadForm`, `JsonLd`, `MobileCtaBar` | shared UI |
| `./wp` | planned | betonplus `lib/wp.ts`, `scripts/scrape.mjs` | WP REST client + snapshot loader (migration-only) |

## Consumption

**Production (planned):** publish as a private package (GitHub Packages) pinned per site for
logic/tokens, plus per-repo PR-sync for the app-shell scaffold. Semver + `qa-build-gate` on every
bump; canary in one site before fleet-wide. See
[../../docs/template-standard.md](../../docs/template-standard.md).

**Pilot mechanism (netomazganim, today):** the package ships raw `.ts`, so a consuming site:
1. adds it as a **packed-tarball** dependency — `npm pack` here, then in the site
   `npm install "../Israeli services sites/packages/site-kit/ishub-site-kit-0.0.0.tgz"`;
2. adds `transpilePackages: ["@ishub/site-kit"]` to `next.config.ts`.

Why a tarball and not a `file:` dir dependency: Next 16's Turbopack could not resolve the symlink a
`file:<dir>` dep creates (its realpath is outside the site's project root and the hub path contains a
space). The tarball installs a real copy inside the site's `node_modules`, which resolves cleanly and
mirrors the eventual published-package flow. Re-running `npm pack` + reinstall is exactly what
`ops/bump-site-kit.ps1` will automate.

## Local checks

```bash
npm install
npm run typecheck   # tsc --noEmit
```

Not yet wired into any site — this package is not published or consumed until the pilot proves a
byte-stable build.
