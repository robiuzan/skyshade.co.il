/**
 * Shared React components. Import from "@ishub/site-kit/components".
 *
 * This subpath exists so "use client" boundaries stay clean and so sites that only need the
 * pure helpers (contact, seo, analytics) do not pull React in at all.
 */
export { SiteImage } from "./SiteImage";
export type { SiteImageProps } from "./SiteImage";
