/**
 * Google Tag Manager helpers — pure strings, so each site renders them in its own layout
 * (mirrors the ./seo `jsonLdScript` pattern; no React/next dependency).
 *
 * Both helpers return `null` when there is no valid container id, so a site can wire the loader
 * in permanently and it stays INERT (renders nothing) until `analytics.gtmId` is set in the
 * manifest — flip the whole fleet on by setting one field.
 *
 * Usage in a root layout:
 *   const gtm = gtmHeadSnippet(manifest.analytics?.gtmId);
 *   const ns  = gtmNoScriptSrc(manifest.analytics?.gtmId);
 *   ...
 *   {gtm && <script dangerouslySetInnerHTML={{ __html: gtm }} />}
 *   {ns  && <noscript><iframe src={ns} height="0" width="0" style={{display:"none"}} /></noscript>}
 */

/** A GTM container id looks like `GTM-XXXXXX`. Guard against garbage/injection. */
const GTM_ID_RE = /^GTM-[A-Z0-9]+$/i;

/** Inline GTM loader snippet for the document head. `null` when the id is missing/invalid. */
export function gtmHeadSnippet(gtmId?: string | null): string | null {
  if (!gtmId || !GTM_ID_RE.test(gtmId)) return null;
  return (
    "(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime()," +
    "event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s)," +
    "dl=l!='dataLayer'?'&l='+l:'';j.async=true;" +
    "j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;" +
    "f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','" +
    gtmId +
    "');"
  );
}

/** The `<noscript>` iframe src (GTM no-JS fallback). `null` when the id is missing/invalid. */
export function gtmNoScriptSrc(gtmId?: string | null): string | null {
  if (!gtmId || !GTM_ID_RE.test(gtmId)) return null;
  return "https://www.googletagmanager.com/ns.html?id=" + gtmId;
}

/**
 * Push a GTM dataLayer event (client-side). Safe no-op when GTM/dataLayer is absent, so it is
 * harmless in local dev and on any site whose `analytics.gtmId` is still null.
 *
 * Use for conversion events the container turns into GA4 events:
 *   trackEvent("lead_submit", { form: "lead", site: siteConfig.domain })
 *
 * Click conversions (call / WhatsApp) do NOT need this — they are tracked in GTM off the
 * `data-cta` attribute and the `tel:` / `wa.me` hrefs, so no JS ships for them.
 */
export function trackEvent(event: string, params: Record<string, unknown> = {}): void {
  if (typeof window === "undefined") return;
  const w = window as unknown as { dataLayer?: Array<Record<string, unknown>> };
  w.dataLayer = w.dataLayer || [];
  w.dataLayer.push({ event, ...params });
}
