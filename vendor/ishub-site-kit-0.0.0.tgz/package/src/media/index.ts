/**
 * Central media pipeline: types + URL builders. Pure, no React.
 *   import { mediaUrl, srcsetFor, type ImageRef } from "@usahub/site-kit/media";
 */
export type { Focal, ImageRef, GalleryItem, GalleryBlock, SiteImages } from "./types";
export {
  widthsFor,
  isVector,
  isLocalPath,
  mediaUrl,
  srcsetFor,
  srcFor,
  ogImageMeta,
  preloadPropsFor,
} from "./url";
export type { TransformOpts } from "./url";
