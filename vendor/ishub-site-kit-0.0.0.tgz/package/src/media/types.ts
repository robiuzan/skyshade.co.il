/**
 * Central media types. Mirrors the `images` block in roster/manifest.schema.json.
 *
 * Pure types + pure functions, no React — so lib/seo.ts and the JSON-LD builders can consume
 * them too. The media service owns the pixels; the manifest owns the keys, dimensions, and alt.
 */

/** Normalized focal point, 0..1 from the top-left. Drives cdn-cgi `gravity` AND CSS object-position. */
export interface Focal {
  x: number;
  y: number;
}

/**
 * One image in the central catalog.
 *
 * `key` is the STABLE object key. The bytes behind it may be replaced without a rebuild, but only
 * at the SAME aspect ratio and at an intrinsic width >= the current one — `width`/`height` below
 * are baked into the emitted HTML, and the srcset ladder is capped at `width`. Swapping in a
 * portrait photo behind a landscape key brings CLS back fleet-wide with no build to catch it.
 */
export interface ImageRef {
  /** Object key, e.g. "zappoacrepairdallas/hero.webp". Never a URL, never a leading slash. */
  key: string;
  /** Content hash of the current bytes. Drives duplicate detection and byte-level rollback. */
  sha256?: string | null;
  /** REQUIRED and non-empty. Enforced structurally by SiteImage and by ops/validate-manifests.ps1. */
  alt: string;
  /** Hebrew alt. Required for the IL fleet; absent from the USA manifest schema. */
  altHe?: string | null;
  /** Intrinsic pixel dimensions. Always emitted on the <img> so there is no CLS. */
  width: number;
  height: number;
  bytes?: number | null;
  /** "vector" is NEVER sent through /cdn-cgi/image — Cloudflare does not rasterize SVG. */
  kind?: "raster" | "vector";
  focal?: Focal | null;
  /** The public/ path this key replaces. The transition fallback while mediaHost is unset. */
  legacySrc?: string | null;
}

export interface GalleryItem extends ImageRef {
  category: string;
}

export interface GalleryBlock {
  /** "baked" = the HTML is the only source. "fetched" = baked snapshot + runtime catalog refresh. */
  mode: "baked" | "fetched";
  /** Absolute URL of the runtime catalog. Required when mode="fetched". Must be on the media host. */
  catalogUrl?: string | null;
  /** Opaque snapshot id. The client swaps state only when the fetched version differs. */
  version?: string | null;
  categories: string[];
  items: GalleryItem[];
}

export interface SiteImages {
  /** Bare hostname of the media service, e.g. "img.example.com". No scheme, no trailing slash. */
  mediaHost: string;
  defaultQuality?: number;
  logo?: ImageRef | null;
  hero?: ImageRef | null;
  og?: ImageRef | null;
  badges?: ImageRef[];
  gallery?: GalleryBlock | null;
}
