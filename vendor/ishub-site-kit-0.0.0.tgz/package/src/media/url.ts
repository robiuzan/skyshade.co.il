/**
 * URL construction for the central media pipeline.
 *
 * Every derivative is produced on the fly by Cloudflare Image Transformations:
 *   https://<mediaHost>/cdn-cgi/image/<options>/<key>
 * Originals are stored once, keyed by content hash, and never re-encoded.
 */
import type { ImageRef, SiteImages } from "./types";

/**
 * The candidate width ladder, covering 1x and 2x:
 *   320/480   small + mid phone (1x)
 *   640/768   phone (2x) + tablet portrait
 *   960/1280  tablet (2x) + laptop
 *   1600/1920 desktop + laptop (2x)
 *   2560      desktop (2x) hard cap
 * Always filtered to <= the intrinsic width: upscaling past the original wastes bytes and softens
 * the image, and the transformation would return the original anyway.
 */
const LADDER = [320, 480, 640, 768, 960, 1280, 1600, 1920, 2560];

const MAX_WIDTH = 2560;

export function widthsFor(intrinsic: number, fixed = false): number[] {
  if (fixed) {
    // Logos and badges render into a CSS-fixed box: 1x and 2x is all a browser can use.
    return Array.from(new Set([intrinsic, intrinsic * 2]))
      .filter((w) => w <= MAX_WIDTH)
      .sort((a, b) => a - b);
  }
  const cap = Math.min(intrinsic, MAX_WIDTH);
  const out = LADDER.filter((w) => w < cap);
  out.push(cap); // always offer the true intrinsic width
  return out;
}

export function isVector(ref: Pick<ImageRef, "key" | "kind">): boolean {
  return ref.kind === "vector" || /\.svgz?$/i.test(ref.key);
}

/** True when `src` is something the site itself serves from public/ rather than a catalog key. */
export function isLocalPath(src: string): boolean {
  return src.startsWith("/") || src.startsWith("./") || src.startsWith("../");
}

export interface TransformOpts {
  width: number;
  quality?: number;
  fit?: "cover" | "contain" | "scale-down" | "crop" | "pad";
  focal?: { x: number; y: number } | null;
}

const clamp01 = (n: number) => Math.min(1, Math.max(0, Math.round(n * 100) / 100));

/**
 * https://<host>/cdn-cgi/image/width=W,quality=Q,format=auto,fit=F[,gravity=XxY]/<key>
 * Option order is fixed so the URL is byte-stable, which keeps the CDN cache key stable.
 */
export function mediaUrl(host: string, key: string, o: TransformOpts): string {
  const parts = [
    `width=${Math.round(o.width)}`,
    `quality=${o.quality ?? 80}`,
    "format=auto",
    `fit=${o.fit ?? "cover"}`,
  ];
  if (o.focal) parts.push(`gravity=${clamp01(o.focal.x)}x${clamp01(o.focal.y)}`);
  return `https://${host}/cdn-cgi/image/${parts.join(",")}/${key.replace(/^\/+/, "")}`;
}

/** srcset string, or undefined when the source must not be transformed (SVG / local path). */
export function srcsetFor(
  images: SiteImages | null | undefined,
  ref: ImageRef,
  opts: { fixed?: boolean; fit?: TransformOpts["fit"]; quality?: number } = {},
): string | undefined {
  if (!images?.mediaHost) return undefined;
  if (isVector(ref) || isLocalPath(ref.key)) return undefined;
  return widthsFor(ref.width, opts.fixed)
    .map(
      (w) =>
        `${mediaUrl(images.mediaHost, ref.key, {
          width: w,
          quality: opts.quality ?? images.defaultQuality,
          fit: opts.fit,
          focal: ref.focal,
        })} ${w}w`,
    )
    .join(", ");
}

/**
 * The single `src` (the no-srcset fallback). Resolution order:
 *   1. already a local path       -> serve verbatim
 *   2. vector                     -> serve from the media host untransformed, else legacy/public
 *   3. media host configured      -> cdn-cgi at the intrinsic width
 *   4. legacySrc set (transition) -> the site's own public/ copy
 *   5. nothing                    -> "/images/" + key, the pre-migration convention
 */
export function srcFor(
  images: SiteImages | null | undefined,
  ref: ImageRef,
  opts: { fit?: TransformOpts["fit"]; quality?: number } = {},
): string {
  if (isLocalPath(ref.key)) return ref.key;
  if (isVector(ref)) {
    if (images?.mediaHost) return `https://${images.mediaHost}/${ref.key.replace(/^\/+/, "")}`;
    return ref.legacySrc ?? `/images/${ref.key}`;
  }
  if (images?.mediaHost) {
    return mediaUrl(images.mediaHost, ref.key, {
      width: ref.width,
      quality: opts.quality ?? images.defaultQuality,
      fit: opts.fit,
      focal: ref.focal,
    });
  }
  return ref.legacySrc ?? `/images/${ref.key}`;
}

/**
 * Open Graph `images` array for Next.js metadata, or undefined when no og image is configured.
 *
 * Returns undefined rather than a placeholder so a site with nothing published simply omits
 * og:image, instead of emitting a URL that 404s. Sites in this fleet previously had NO og:image
 * at all, so anything here is an improvement - but a broken one would be worse than none.
 *
 * Usage in a site's app/layout.tsx:
 *   openGraph: { ..., images: ogImageMeta(manifest.images) }
 */
export function ogImageMeta(images: SiteImages | null | undefined) {
  const og = images?.og;
  if (!og) return undefined;
  return [
    {
      url: srcFor(images, og, { fit: "cover" }),
      width: og.width,
      height: og.height,
      // Hebrew first: this fleet is RTL and altHe is the string that actually ships.
      alt: og.altHe || og.alt || undefined,
    },
  ];
}

/**
 * Props for a <link rel="preload"> of the LCP image. Emit in the page <head>, not the body.
 *
 * Pair this with a <link rel="preconnect"> to the media host. Without the preconnect the hero
 * moves from a warm same-origin connection to a cold third-party origin (DNS + TCP + TLS) and
 * LCP regresses — the single easiest way to make this pipeline measure as a performance loss.
 */
export function preloadPropsFor(
  images: SiteImages | null | undefined,
  ref: ImageRef,
  sizes: string,
  opts: { fit?: TransformOpts["fit"]; quality?: number } = {},
) {
  const srcSet = srcsetFor(images, ref, opts);
  return {
    rel: "preload" as const,
    as: "image" as const,
    href: srcFor(images, ref, opts),
    ...(srcSet ? { imageSrcSet: srcSet, imageSizes: sizes } : {}),
    fetchPriority: "high" as const,
  };
}
