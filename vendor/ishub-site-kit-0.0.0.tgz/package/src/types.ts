/**
 * The normalized per-site config shape. Mirrors roster/manifest.schema.json.
 *
 * Every site's `lib/site*.ts` is refactored to satisfy `SiteManifest` (replacing the four
 * divergent shapes found in the repos), and components read from it instead of hardcoding.
 */

import type { SiteImages } from "./media/types";

export interface SiteContact {
  /** Human format, e.g. "055-6601006". */
  phoneDisplay: string;
  /** E.164, e.g. "+972556601006". */
  phoneE164: string;
  /** E.164 used for wa.me. */
  whatsappE164: string;
  email: string;
  /** Web3Forms public access key (per-site UUID). Delivery inbox = contact.email. Public, safe to commit. null until provisioned. */
  formAccessKey?: string | null;
  /** true ONLY when this site does not use the shared lead number (currently only dangates). */
  phoneOverride?: boolean;
}

export interface SiteBrand {
  themeColor?: string | null;
  primary?: string | null;
  secondary?: string | null;
  accent?: string | null;
  fontHeading?: string | null;
  fontBody?: string | null;
}

export interface SiteSchema {
  /** schema.org LocalBusiness subtype for this trade (drives JSON-LD @type). null until migrated. */
  type: string | null;
  priceRange?: string | null;
  areaServed?: string | null;
  openingHours?: Array<Record<string, unknown>>;
  address?: Record<string, unknown> | null;
  sameAs?: string[];
}

export interface SiteAnalytics {
  /** GTM container LOADED BY THE SITE. The fleet shares one container across all domains. */
  gtmId?: string | null;
  /**
   * This site's GA4 Measurement ID. NOT loaded by the site — the shared container resolves it
   * per hostname via a Lookup Table variable. Recorded here as the source of truth for that
   * table; see the hub's `docs/gtm-setup.md`.
   */
  ga4MeasurementId?: string | null;
  googleSiteVerification?: string | null;
}

export interface SiloEntry {
  slug: string;
  name: string;
}

export interface SiteSilos {
  services?: SiloEntry[];
  cities?: SiloEntry[];
  brands?: SiloEntry[];
  faults?: SiloEntry[];
}

export interface SiteManifest {
  domain: string;
  url: string;
  /**
   * Central media pipeline. Written by ops/sync-media.ps1 from the Media Studio catalog;
   * hand-editing is allowed only for alt text. Absent = the site still serves images from its
   * own public/ directory.
   */
  images?: SiteImages | null;
  brandName?: string | null;
  brandNameEn?: string | null;
  legalName?: string | null;
  locale: string;
  dir: "rtl" | "ltr";
  foundedYear?: number | null;
  tagline?: string | null;
  shortPitch?: string | null;
  contact: SiteContact;
  brand: SiteBrand;
  schema: SiteSchema;
  analytics?: SiteAnalytics;
  silos?: SiteSilos;
}
