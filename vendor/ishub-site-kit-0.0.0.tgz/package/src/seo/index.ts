/**
 * Shared schema.org JSON-LD builders, driven by the normalized SiteManifest.
 *
 * Pure: no React, no `next`. Callers render the output themselves via
 * `<script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLdScript(node) }} />`.
 *
 * Generalized from betonplus.co.il/lib/seo.ts (the fleet's richest builder) so a single
 * source produces the LocalBusiness/Service/FAQ/Breadcrumb graph for every site; the trade
 * @type and NAP/area/hours all come from the manifest instead of being hardcoded per site.
 */
import type { SiteManifest } from "../types";

export type JsonLd = Record<string, unknown>;

const abs = (m: SiteManifest, path: string): string =>
  /^https?:\/\//.test(path) ? path : `${m.url}${path.startsWith("/") ? path : `/${path}`}`;

/** Drop null/undefined/""/[] so fields absent from the manifest simply vanish from the node. */
function prune<T extends Record<string, unknown>>(obj: T): T {
  for (const k of Object.keys(obj)) {
    const v = obj[k];
    if (v === null || v === undefined || v === "" || (Array.isArray(v) && v.length === 0)) {
      delete obj[k];
    }
  }
  return obj;
}

const DAY_MAP: Record<string, string> = {
  su: "Sunday",
  mo: "Monday",
  tu: "Tuesday",
  we: "Wednesday",
  th: "Thursday",
  fr: "Friday",
  sa: "Saturday",
};

interface HourSpec {
  "@type": "OpeningHoursSpecification";
  dayOfWeek: string | string[];
  opens: string;
  closes: string;
}

/** Accept raw schema.org OpeningHoursSpecification objects OR a simple {days,opens,closes}. */
function normalizeHours(hours: unknown): HourSpec[] | undefined {
  if (!Array.isArray(hours) || hours.length === 0) return undefined;
  return hours.map((h) => {
    const o = h as Record<string, unknown>;
    if (o["@type"] === "OpeningHoursSpecification") return o as unknown as HourSpec;
    const days = Array.isArray(o.days)
      ? (o.days as string[]).map((d) => DAY_MAP[String(d).slice(0, 2).toLowerCase()] ?? d)
      : [];
    return {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: days.length === 1 ? (days[0] as string) : days,
      opens: String(o.opens ?? ""),
      closes: String(o.closes ?? ""),
    };
  });
}

export interface LocalBusinessOpts {
  /** Absolute or site-relative image URL. */
  image?: string;
  /** Absolute or site-relative logo URL. */
  logo?: string;
  /** Override areaServed (e.g. an explicit list of areas) instead of manifest.schema.areaServed. */
  areaServed?: string | string[];
  /** Override the primary schema `name` (default manifest.brandName). Some sites use English-primary. */
  name?: string;
  /** Override `alternateName` (default: brandNameEn when it differs from the name). */
  alternateName?: string;
}

/** Site-wide LocalBusiness-subtype node. `@type` comes from manifest.schema.type. */
export function localBusinessJsonLd(m: SiteManifest, opts: LocalBusinessOpts = {}): JsonLd {
  const s = m.schema ?? ({ type: null } as SiteManifest["schema"]);
  const areaRaw = opts.areaServed ?? s.areaServed ?? undefined;
  const areaServed = Array.isArray(areaRaw)
    ? areaRaw.map((name) => ({ "@type": "AdministrativeArea", name }))
    : areaRaw
      ? { "@type": "AdministrativeArea", name: areaRaw }
      : undefined;

  const address = s.address
    ? { "@type": "PostalAddress", ...(s.address as Record<string, unknown>) }
    : undefined;

  const name = opts.name ?? m.brandName ?? m.brandNameEn ?? undefined;
  const alt =
    opts.alternateName ?? (m.brandNameEn && m.brandNameEn !== name ? m.brandNameEn : undefined);

  return prune({
    "@context": "https://schema.org",
    "@type": s.type ?? "LocalBusiness",
    "@id": `${m.url}/#business`,
    name,
    alternateName: alt,
    description: m.shortPitch ?? m.tagline ?? undefined,
    url: m.url,
    telephone: m.contact.phoneE164,
    email: m.contact.email ?? undefined,
    foundingDate: m.foundedYear ? String(m.foundedYear) : undefined,
    image: opts.image ? abs(m, opts.image) : undefined,
    logo: opts.logo ? abs(m, opts.logo) : undefined,
    priceRange: s.priceRange ?? undefined,
    areaServed,
    address,
    openingHoursSpecification: normalizeHours(s.openingHours),
    knowsLanguage: (m.locale ?? "he").split("-")[0],
    sameAs: s.sameAs ?? undefined,
  });
}

/** Service node for a single service. Caller passes the service data (does any slug lookup). */
export function serviceJsonLd(
  m: SiteManifest,
  svc: { name: string; description?: string; slug?: string; url?: string },
): JsonLd {
  return prune({
    "@context": "https://schema.org",
    "@type": "Service",
    name: svc.name,
    serviceType: svc.name,
    description: svc.description ?? undefined,
    url: svc.url ?? (svc.slug ? `${m.url}/services/${svc.slug}/` : undefined),
    provider: { "@type": m.schema?.type ?? "LocalBusiness", "@id": `${m.url}/#business` },
    areaServed: m.schema?.areaServed
      ? { "@type": "AdministrativeArea", name: m.schema.areaServed }
      : undefined,
  });
}

/** FAQPage from Q/A pairs. Accepts either {q,a} or {question,answer} shapes. */
export function faqJsonLd(
  items: Array<{ q?: string; a?: string; question?: string; answer?: string }>,
): JsonLd {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((f) => ({
      "@type": "Question",
      name: f.q ?? f.question ?? "",
      acceptedAnswer: { "@type": "Answer", text: f.a ?? f.answer ?? "" },
    })),
  };
}

/** BreadcrumbList from home to the current page. */
export function breadcrumbJsonLd(
  m: SiteManifest,
  crumbs: Array<{ name: string; path: string }>,
): JsonLd {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: crumbs.map((c, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: c.name,
      item: abs(m, c.path),
    })),
  };
}

/** Sanitized JSON string for a <script type="application/ld+json"> tag (escapes `<`). */
export function jsonLdScript(data: JsonLd | JsonLd[]): string {
  return JSON.stringify(data).replace(/</g, "\\u003c");
}
