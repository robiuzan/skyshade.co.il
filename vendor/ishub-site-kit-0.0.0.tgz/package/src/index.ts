/**
 * Barrel entry for @ishub/site-kit.
 * Root import is the most bundler-portable (single specifier, standard main/module/types),
 * so consuming sites do `import { telHref, whatsappHref, type SiteManifest } from "@ishub/site-kit"`.
 * Subpath exports (./types, ./contact, ./seo) remain available for tree-shaking-conscious callers.
 */
export * from "./types";
export * from "./contact";
export * from "./seo";
export * from "./analytics";
