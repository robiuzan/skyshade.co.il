/**
 * Barrel entry for @ishub/site-kit.
 * Root import is the most bundler-portable (single specifier, standard main/module/types),
 * so consuming sites do `import { telHref, whatsappHref, type SiteManifest } from "@ishub/site-kit"`.
 * Subpath exports (./types, ./contact, ./seo) remain available for tree-shaking-conscious callers.
 *
 * React components live on their own subpath so "use client" boundaries stay clean:
 *   import { SiteImage } from "@ishub/site-kit/components";
 */
export * from "./types";
export * from "./media";
export * from "./contact";
export * from "./seo";
export * from "./analytics";
