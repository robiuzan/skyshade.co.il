/**
 * Normalized contact helpers — the single replacement for the four drifted variants:
 *   betonplus telHref/whatsappHref (module consts), netomazganim whatsappHref(message),
 *   gagoline whatsappHref(message), visionsecurity whatsappUrl(text)/TEL_HREF.
 * Components import these and pass the manifest; no number is ever hardcoded.
 */
import type { SiteManifest } from "../types";

/** `tel:` href for click-to-call. */
export function telHref(m: SiteManifest): string {
  return `tel:${m.contact.phoneE164}`;
}

/** wa.me deep link, with an optional pre-filled message. */
export function whatsappHref(m: SiteManifest, message?: string): string {
  const digits = m.contact.whatsappE164.replace(/\D/g, "");
  const base = `https://wa.me/${digits}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

/** Human-readable phone for display in the UI. */
export function phoneDisplay(m: SiteManifest): string {
  return m.contact.phoneDisplay;
}

/** True when this site uses its own number rather than the shared lead line. */
export function usesOwnNumber(m: SiteManifest): boolean {
  return m.contact.phoneOverride === true;
}
